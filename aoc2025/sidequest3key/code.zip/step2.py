#!/usr/bin/env python3

import base64
import sys
import zlib

def xor_bytes(data: bytes, key: bytes) -> bytes:
    """XOR each byte of data with the key, repeating the key as needed."""
    key_len = len(key)
    return bytes([b ^ key[i % key_len] for i, b in enumerate(data)])

def pad_base32_line(line: str) -> str:
    """Pad a Base32 line to a multiple of 8 characters with '='."""
    line = line.strip()
    if not line:
        return line
    remainder = len(line) % 8
    if remainder != 0:
        line += '=' * (8 - remainder)
    return line


with open("base64.txt", "wb") as f:
    f.write(b'\x00')

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 convert_base32.py base32.txt")
        sys.exit(1)

    input_file = sys.argv[1]

    # Read Base32 data line by line
    with open(input_file, "r") as f:
        lines = f.readlines()

    decoded_bytes = b''

    # Decode each line separately, preserving spaces/newlines
    for line in lines:
        line = line.rstrip('\n')
        if not line.strip():
            continue  # skip empty lines
        padded_line = pad_base32_line(line)
        try:
            decoded_line = base64.b32decode(padded_line, casefold=True)
        except Exception as e:
            print(f"Base32 decode failed on line: {line}")
            print("Error:", e)
            sys.exit(1)
        decoded_bytes = decoded_line
        
        # XOR with key
        key = b"h0pp3r"
        xored_bytes = xor_bytes(decoded_bytes, key)

        # zlib inflate
        try:
            inflated_bytes = zlib.decompress(xored_bytes)
            #print(inflated_bytes)
            with open("base64.txt", "ab") as f:
                f.write(inflated_bytes)

        except Exception as e:
            print("zlib decompression failed:", e)
            sys.exit(1)

    print("Success! Saved decompressed output to 'base64.txt'")


if __name__ == "__main__":
    main()

