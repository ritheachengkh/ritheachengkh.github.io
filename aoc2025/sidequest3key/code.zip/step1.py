import sys
from PIL import Image

EXPECTED_WIDTH = 512

def grayscale_to_base32_text(image_path):
    # STEP 1: Load grayscale image
    img = Image.open(image_path).convert("L")
    width, height = img.size

    if width != EXPECTED_WIDTH:
        raise ValueError(f"Image width must be {EXPECTED_WIDTH}px, got {width}px")

    # STEP 2: Extract pixel data
    pixel_data = list(img.getdata())

    # Remove padding zeros that were added during encoding
    pixel_data = [p for p in pixel_data if p != 0]

    # STEP 3: Convert pixel values back to Base32 bytes
    base32_bytes = bytes(pixel_data)

    # Save Base32 data to text file
    output_path = "base32.txt"
    with open(output_path, "wb") as f:
        f.write(base32_bytes)

    print("Process complete:")
    print(f"- Image size: {width}x{height}")
    print(f"- Base32 data length: {len(base32_bytes)} bytes")
    print(f"- Saved as: {output_path}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 script.py <grayscaleimage.png>")
        sys.exit(1)

    grayscale_to_base32_text(sys.argv[1])
