import requests
import re
import urllib
import base64


# Credentials for natas28
username = "natas28"
password = "1JNwQM1Oi6J6j1k49Xyw7ZN6pXMQInVj"

# Target URL
url = "http://natas28.natas.labs.overthewire.org"

session = requests.Session()

for i in range(1,100):
    response = session.post(
        url,
        data={"query":"C"*i},
        auth=(username, password)
    )

    # query data after (http://natas28.natas.labs.overthewire.org/search.php/?query=)
    query_value = base64.b64decode(requests.utils.unquote(response.url[60:]))

    print("Number_of_C", i, "response_length", len(query_value))
